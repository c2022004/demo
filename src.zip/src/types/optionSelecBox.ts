export interface SelectBoxType{
    value: string | number | boolean | undefined
    label: string | number
    disable?: boolean;
    valueClassName?: string;
    

}