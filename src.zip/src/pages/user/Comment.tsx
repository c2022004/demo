import React from "react";
function Commnet() {
  return <>hello</>;
}

export default Commnet;
