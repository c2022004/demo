import React from "react";

function DisableUser() {
  return <></>;
}

export default DisableUser;
