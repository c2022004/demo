import React from "react";

function ReportUser() {
  return <></>;
}

export default ReportUser;
