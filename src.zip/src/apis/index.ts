export const DOMAIN = "http://localhost:8088";
export const FRONT_END_DOMAIN = "http://localhost:5173";