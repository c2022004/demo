import React from "react"

function AdminHome() {
  return (
    <div>AdminHome</div>
  )
}
export default AdminHome