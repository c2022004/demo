import React from "react";
function NotFound() {
  return <h1>Trang không tồn tại</h1>;
}

export default NotFound;
