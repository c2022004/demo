const userRoutes = {
  home: "/",
  addToCart: "/gio-hang",
  checkout: "/thanh-toan",
  comment: "/binh-luan",
  profile: "/thong-tin-nguoi-dung",
};

export default userRoutes;
