const publicRoutes = {
  home: "/",
  productDetail: "/chi-tiet-san-pham",
  login: "/dang-nhap",
  signIn: "/dang-ky",
  importFile: "/import-file",
  productList: "/danh-sach-san-pham",
};

export default publicRoutes;
